function melodyMaker(notes) {
  let output = [];

  for (let [note, duration] of notes) {
    // console.log(note)
    // console.log(output[output.length - 1][0])
    if (output.length && output[output.length - 1][0] === note) {
      output[output.length - 1][1] += duration;
    } else {
      output.push([note, duration]); 
    }
  }

  return output;
}

console.log(melodyMaker([
  ["A", 1],
  ["A", 2],
  ["B", 1]
]));

